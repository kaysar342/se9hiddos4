#!/bin/bash

# Kullanıcı adını al
read -p "Yeni kullanıcı adını girin: " username

# Rasgele bir şifre oluştur
password=$(< /dev/urandom tr -dc _A-Z-a-z-0-9 | head -c12)

# Kullanıcıyı ekleyin
sudo adduser  $username

# Oluşturulan kullanıcıya şifreyi atayın
echo "$username:$password" | sudo chpasswd

# Kullanıcının ev dizinine gidin
cd /home/$username

# Şifreyi bir dosyaya kaydedin
echo "Kullanıcı Adı: $username" > password_info.txt
echo "Şifre: $password" >> password_info.txt

# Dosyayı sadece kullanıcı okuyabilsin diğerlerinin erişimini engelleyin
chmod 400 password_info.txt

echo "Kullanıcı oluşturuldu. Şifre bilgileri 'password_info.txt' dosyasına kaydedildi."
